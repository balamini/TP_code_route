export class Categorie {
    id: number;
    title: string;
    image: string;
    forme: string;
    couleur: string;
    texte: string;
    categorie: string;
}

export class Panneau {
    id: number;
    title: string;
    image: string;
    categorie: string;
    commentaire: string;
}
